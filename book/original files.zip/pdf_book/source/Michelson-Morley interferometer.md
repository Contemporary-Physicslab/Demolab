# Michelson-Morley interferometer 

Aim: To show the Michelson-Morley interferometer and how sensitive such a device is.

Subjects: 6 D40 (Interferometers)

Diagram:

![](https://cdn.mathpix.com/cropped/2024_06_24_a992ce0e337ecb6b2e4eg-1.jpg?height=1317&width=1198&top_left_y=469&top_left_x=561)

Equipment:

Presentation:

Sources:

- Giancoli, D.G., Physics for scientists and engineers with modern physics, pag. $920-922$
- Hecht, Eugene, Optics, pag. 399-403

