# Curved lightbeams 

![](https://cdn.mathpix.com/cropped/2024_06_24_dd0dcadd3f9a85bbc8f7g-1.jpg?height=1658&width=1430&top_left_y=294&top_left_x=304)

Equipment:

- 


## Curved lightbeams

Presentation:

Figures:

![](https://cdn.mathpix.com/cropped/2024_06_24_dd0dcadd3f9a85bbc8f7g-2.jpg?height=634&width=1223&top_left_y=388&top_left_x=516)

Figure 1

- Hecht, Eugene, Optics, pag. 107

