# Vibrating stopwatch 

Aim: $\quad$ To show an example of conservation of angular momentum.

Subjects: 1Q40 (Conservation of Angular Momentum)

Diagram:

![](https://cdn.mathpix.com/cropped/2024_06_24_e6eb7b532a7cdf8c3b70g-1.jpg?height=642&width=588&top_left_y=392&top_left_x=885)

Equipment:

- Mechanical stopwatch
- Mirror attached to the stopwatch
- Laser

Presentation: The running stopwatch is hung on three strings, so it can rotate easily. The whole assembly is mounted inside a transparent acrylic tube, to prevent movements due to airflows. The laser beam projects a spot via the mirror on the wall a couple of meters away. Observing the laserspot on the wall it can be seen that the total system vibrates.

Observing the fly of the stopwatch and the movement of the laserspot, it can be seen that these directions of movement are opposite.

Explanation: No external force is applied to this system. The casing of the stopwatch has to move opposite to the fly. Since the casing has a larger mass than the fly, the observed deflections will be small.

Remarks: Since this set-up is very sensitive (e.g. to air movements), it is advisable to place the experiment in a show case. Pushing a knob activates the laser.

Sources:

- Borghouts, A.N., Inleiding in de Mechanica, pag. 175

